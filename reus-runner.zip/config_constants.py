CONFIG_PROPERTIES_PATH: str = "./config.properties"
